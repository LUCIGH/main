    <!-- Footer -->
    <div class="footer">
        <div class="container flex">
            <div class="footer-about">
                <h2>Về Chúng Tôi</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime
                    aspernatur sit deleniti enim voluptas voluptatum incidunt rerum,
                    exercitationem voluptate nemo quo impedit ad perspiciatis tempore
                    nulla dolore fugit, fuga eos.
                </p>
            </div>
            <div class="footer-category">
                <h2>Menu</h2>

                <ul>
                    <li><a href="index.php?page_layout=menu&category=1">Burger</a></li>
                    <li><a href="index.php?page_layout=menu&category=2">Gà</a></li>
                    <li><a href="index.php?page_layout=menu&category=3">Pizza</a></li>
                    <li><a href="index.php?page_layout=menu&category=4">Nước Uống</a></li>
                </ul>
            </div>

            <div class="quick-links">
                <h2>Thông Tin</h2>

                <ul>
                    <li><a href="#">Câu Chuyện</li>
                    <li><a href="#">Khuyến Mãi</li>
                    <li><a href="https://www.youtube.com/@MrBeast">Youtube</li>
                    <li><a href="https://www.facebook.com/tonducthanguniversity">Facebook</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Footer -->